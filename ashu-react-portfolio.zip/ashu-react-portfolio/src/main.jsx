import React from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight, Github, Linkedin, Mail, MapPin, Code2, Database,
  Braces, Globe, ChevronDown, ExternalLink
} from "lucide-react";
import "./styles.css";

const profile = {
  name: "Ashu Prajapati",
  role: "CSE Student · Developer · Problem Solver",
  location: "Gwalior, Madhya Pradesh, India",
  college: "Madhav Institute of Technology & Science, Gwalior",
  linkedin: "https://www.linkedin.com/in/ashu-prajapati-508532300/",
  github: "https://github.com/",
  email: "mailto:your-email@example.com"
};

const skills = [
  { name: "C++ & DSA", icon: Code2, text: "Data structures, algorithms, problem solving" },
  { name: "JavaScript", icon: Braces, text: "Modern JavaScript and web development" },
  { name: "React.js", icon: Globe, text: "Component-based frontend development" },
  { name: "Node.js & Express", icon: Code2, text: "Backend APIs and server-side development" },
  { name: "Python", icon: Braces, text: "Programming fundamentals and problem solving" },
  { name: "SQL & DBMS", icon: Database, text: "Queries, normalization and database concepts" }
];

const projects = [
  {
    title: "Vocal Canvas",
    tag: "Main Project",
    description:
      "A web-based communication skills platform designed for college students, covering English speaking, communication, interview preparation, presentation practice and related learning modules.",
    tech: ["React", "Node.js", "Express", "MongoDB"],
    featured: true
  },
  {
    title: "Carbon Footprint Tracker",
    tag: "CSE Micro Project",
    description:
      "A web application concept for estimating personal carbon footprint from fuel, electricity and waste inputs, with goals and environmental information.",
    tech: ["C++", "HTML", "CSS", "JavaScript"],
    featured: false
  },
  {
    title: "Jal Drishti",
    tag: "Dashboard",
    description:
      "A water-monitoring dashboard concept using a React/Vite frontend with map-based visualization and periodic monitoring data.",
    tech: ["React", "Vite", "Chakra UI", "Maps"],
    featured: false
  }
];

const journey = [
  ["CSE Foundation", "Building strong fundamentals in programming, DSA, DBMS and software engineering."],
  ["Web Development", "Learning JavaScript, React, Node.js, Express and full-stack development through projects."],
  ["Problem Solving", "Practicing coding problems and improving algorithmic thinking with C++ and Python."],
  ["Next Goal", "Become a strong software developer and build practical products that solve real problems."]
];

function App() {
  return (
    <div className="site">
      <nav className="nav">
        <a className="brand" href="#home"><span>A</span> Ashu.</a>
        <div className="navlinks">
          <a href="#about">About</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#journey">Journey</a>
        </div>
        <a className="nav-cta" href={profile.linkedin} target="_blank" rel="noreferrer">
          LinkedIn <ArrowUpRight size={16}/>
        </a>
      </nav>

      <main>
        <section id="home" className="hero">
          <div className="hero-glow glow-one"></div>
          <div className="hero-glow glow-two"></div>
          <div className="hero-copy">
            <div className="eyebrow"><span className="dot"></span> Open to learning & opportunities</div>
            <h1>Hi, I'm <em>Ashu</em>.<br/>I build things for the web.</h1>
            <p className="hero-text">
              CSE student at MITS Gwalior, passionate about programming, DSA and
              full-stack web development. I learn by building, experimenting and solving problems.
            </p>
            <div className="hero-actions">
              <a className="primary-btn" href="#projects">Explore my work <ArrowUpRight size={18}/></a>
              <a className="ghost-btn" href={profile.linkedin} target="_blank" rel="noreferrer">
                <Linkedin size={18}/> LinkedIn
              </a>
            </div>
            <div className="quick-meta">
              <span><MapPin size={15}/> {profile.location}</span>
              <span><Code2 size={15}/> CSE Student</span>
            </div>
          </div>

          <div className="hero-card">
            <div className="portrait">
              <div className="portrait-letter">A</div>
            </div>
            <div className="code-card">
              <div className="code-top"><span></span><span></span><span></span></div>
              <pre>{`const ashu = {
  focus: "Software Development",
  stack: ["C++", "JS", "React"],
  mindset: "Learn by building"
};`}</pre>
            </div>
          </div>
          <a className="scroll" href="#about"><ChevronDown size={18}/> scroll to explore</a>
        </section>

        <section id="about" className="section about">
          <div className="section-label">01 — About me</div>
          <div className="section-grid">
            <div>
              <h2>Curious mind.<br/><span>Builder's mindset.</span></h2>
            </div>
            <div className="about-copy">
              <p>
                I'm a Computer Science student at <strong>MITS Gwalior</strong>.
                My current focus is becoming a well-rounded software developer by
                strengthening my DSA, programming and full-stack development skills.
              </p>
              <p>
                I enjoy turning ideas into working projects. From communication-learning
                platforms to dashboards and environmental tools, I like projects where
                technology has a clear purpose.
              </p>
              <p>
                Outside coding, I’m also working on my communication and English skills,
                because I believe a good developer needs both technical ability and the
                ability to explain ideas clearly.
              </p>
              <div className="facts">
                <div><b>CSE</b><span>Field of study</span></div>
                <div><b>Web</b><span>Current focus</span></div>
                <div><b>DSA</b><span>Core practice</span></div>
              </div>
            </div>
          </div>
        </section>

        <section id="skills" className="section skills-section">
          <div className="section-label">02 — Skills</div>
          <div className="section-head">
            <h2>Tools I use to <span>build.</span></h2>
            <p>Growing my stack one project at a time.</p>
          </div>
          <div className="skills-grid">
            {skills.map(({name, icon: Icon, text}) => (
              <div className="skill-card" key={name}>
                <div className="skill-icon"><Icon size={22}/></div>
                <h3>{name}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="projects" className="section projects">
          <div className="section-label">03 — Selected work</div>
          <div className="section-head">
            <h2>Things I've <span>built.</span></h2>
            <p>Projects are where I turn concepts into practical experience.</p>
          </div>
          <div className="project-list">
            {projects.map((project, i) => (
              <article className={"project " + (project.featured ? "featured" : "")} key={project.title}>
                <div className="project-num">0{i + 1}</div>
                <div className="project-body">
                  <div className="project-tag">{project.tag}</div>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className="chips">{project.tech.map(t => <span key={t}>{t}</span>)}</div>
                </div>
                <div className="project-arrow"><ArrowUpRight size={22}/></div>
              </article>
            ))}
          </div>
        </section>

        <section id="journey" className="section journey">
          <div className="section-label">04 — My journey</div>
          <div className="section-grid journey-grid">
            <div>
              <h2>Learning is<br/><span>the journey.</span></h2>
              <p className="journey-intro">
                I'm continuously improving — from core CS concepts to building real web applications.
              </p>
            </div>
            <div className="timeline">
              {journey.map(([title, desc], i) => (
                <div className="timeline-item" key={title}>
                  <div className="timeline-marker">{i + 1}</div>
                  <div><h3>{title}</h3><p>{desc}</p></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="contact">
          <div className="contact-inner">
            <div className="section-label">05 — Let's connect</div>
            <h2>Have an idea?<br/><em>Let's build.</em></h2>
            <p>I'm always interested in learning, collaborating and building useful things.</p>
            <div className="contact-actions">
              <a className="primary-btn" href={profile.linkedin} target="_blank" rel="noreferrer">
                <Linkedin size={18}/> Connect on LinkedIn
              </a>
              <a className="ghost-btn light" href={profile.github} target="_blank" rel="noreferrer">
                <Github size={18}/> GitHub
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <span>© {new Date().getFullYear()} Ashu Prajapati</span>
        <span>Designed & built with React</span>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);